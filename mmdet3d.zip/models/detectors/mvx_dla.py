# Copyright (c) OpenMMLab. All rights reserved.
import torch
from mmcv.runner import force_fp32
from torch.nn import functional as F

from ..builder import DETECTORS
from .mvx_two_stage import MVXTwoStageDetector
from mmdet3d.core.bbox.structures import get_proj_mat_by_coord_type
from mmdet3d.models.fusion_layers.point_fusion import point_sample


def sample_single(img_feats, pts, img_meta):
        """Sample features from single level image feature map.

        Args:
            img_feats (torch.Tensor): Image feature map in shape
                (1, C, H, W).
            pts (torch.Tensor): Points of a single sample.
            img_meta (dict): Meta information of the single sample.

        Returns:
            torch.Tensor: Single level image features of each point.
        """
        # TODO: image transformation also extracted
        img_scale_factor = (
            pts.new_tensor(img_meta['scale_factor'][:2])
            if 'scale_factor' in img_meta.keys() else 1)
        img_flip = img_meta['flip'] if 'flip' in img_meta.keys() else False
        img_crop_offset = (
            pts.new_tensor(img_meta['img_crop_offset'])
            if 'img_crop_offset' in img_meta.keys() else 0)
        proj_mat = get_proj_mat_by_coord_type(img_meta, 'LIDAR')#LIDAR
        img_pts = point_sample(
            img_meta=img_meta,
            img_features=img_feats,
            points=pts,
            proj_mat=pts.new_tensor(proj_mat),
            coord_type='LIDAR',#LIDAR
            img_scale_factor=img_scale_factor,
            img_crop_offset=img_crop_offset,
            img_flip=img_flip,
            img_pad_shape=img_meta['input_shape'][:2],
            img_shape=img_meta['img_shape'][:2],
            aligned=True,#True
            padding_mode='zeros',#'zeros'
            align_corners=True,#True
        )
        return img_pts


@DETECTORS.register_module()
class MVXDla(MVXTwoStageDetector):
    """Multi-modality VoxelNet using Faster R-CNN."""


    def __init__(self, **kwargs):
        super(MVXDla, self).__init__(**kwargs)

    def extract_pts_feat(self, pts, img_feats, img_metas):
        """Extract features of points."""
        if not self.with_pts_bbox:
            return None

        #提取特征，此处6张图片采用的是相加，需要考虑别的策略，如一些映射转化
        img_feat = img_feat.view(len(img_metas),-1,64,img_feat.shape[2],img_feat.shape[3])

        img_pts = []
        for i in range(len(img_metas)):
            img_feats_per_img = []
            for level in range(img_feat[i].shape[0]):
                img_feats_per_img.append(sample_single(img_feat[i][level].unsqueeze(dim = 0),pts[i][:,:3],img_metas[i]))
            img_feats_per_img = sum(img_feats_per_img)
            img_feats_per_img = torch.cat([img_feats_per_img,pts[i]],dim = 1)
            img_pts.append(img_feats_per_img)

        voxels, num_points, coors = self.voxelize(img_pts)#做了一个强行concat磨平了batch
        voxel_features = self.pts_voxel_encoder(voxels, num_points, coors)
        batch_size = coors[-1, 0] + 1#记录了batch信息重新拆分
        x1 = self.pts_middle_encoder(voxel_features[:,:5], coors, batch_size)
        x2 = self.img_middle_encoder(voxel_features[:,5:], coors ,batch_size)
        x = torch.cat([x1,x2],dim = 1)
        x_ = self.pts_backbone(x)
        if self.with_pts_neck:
            x_ = self.pts_neck(x_)
        x = torch.cat([x,x_],dim = 1)
        return x
    
    

